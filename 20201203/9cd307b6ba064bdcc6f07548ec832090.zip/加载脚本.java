//初始化部分常量
import android.os.Environment;
String RootPath =Environment.getExternalStorageDirectory().getAbsoluteFile()+"/QQ复读机/脚本目录/";
load(RootPath+"core/import.java");
String Version = "0.5.0";
int Int_Version = 50;
String MyUin;
String MyName;
long StartTime = System.currentTimeMillis();
public static String bytesToHex(byte[] bytes)
{
	StringBuffer sb = new StringBuffer();
	for(int i = 0; i < bytes.length; i++)
	{
		String hex = Integer.toHexString(bytes[i] & 0xFF);
		if(hex.length() < 2)
		{
			sb.append(0);
		}
		sb.append(hex);
	}
	return sb.toString();
}
public static byte hexToByte(String inHex){  
   return (byte)Integer.parseInt(inHex,16);  
}  
public static byte[] hexToByteArray(String inHex)
{
	int hexlen = inHex.length();
	byte[] result;
	if(hexlen % 2 == 1)
	{
		//奇数  
		hexlen++;
		result = new byte[(hexlen / 2)];
		inHex = "0" + inHex;
	}
	else
	{
		//偶数  
		result = new byte[(hexlen / 2)];
	}
	int j = 0;
	for(int i = 0; i < hexlen; i += 2)
	{
		result[j] = hexToByte(inHex.substring(i, i + 2));
		j++;
	}
	return result;
}
	//检查文件状态
Activity ThisActivity = null;
public void initActivity()
{
	Class clazz = Class.forName("android.app.ActivityThread");
	Object ActivityThread = FieldUtils.getStaticField(clazz, "sCurrentActivityThread");
	Field activitiesField = clazz.getDeclaredField("mActivities");
	Application application = FieldUtils.getField(ActivityThread, "mInitialApplication");
	activitiesField.setAccessible(true);
	Map activities = (Map) activitiesField.get(ActivityThread);
	for(Object activityRecord: activities.values())
	{
		Class activityRecordClass = activityRecord.getClass();
		Field pausedField = activityRecordClass.getDeclaredField("paused");
		pausedField.setAccessible(true);
		if(!pausedField.getBoolean(activityRecord))
		{
			Field activityField = activityRecordClass.getDeclaredField("activity");
			activityField.setAccessible(true);
			ThisActivity = (Activity) activityField.get(activityRecord);
		}
	}
}
//询问并更新文件
try
{
	load(RootPath + "core/ToastApis.java");
	load(RootPath + "core/ItemCore.java");
	load(RootPath + "core/Enc.java");
	load(RootPath + "core/MsgApiBridge_zqq.java");
	load(RootPath + "core/ModuleLoader.java");
}
catch(Exception e)
{
	Toast("" + e);
}
//加载核心文件