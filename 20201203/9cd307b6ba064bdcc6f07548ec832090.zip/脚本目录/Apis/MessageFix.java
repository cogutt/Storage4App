public class GameStatusClass
{
	String GameTheName = "---绿逗Java---";
	String CardDefImages = "http://gchat.qpic.cn/gchatpic_new/184757891/582544273-2231011334-20F7CBF5F291BE1A925A502B381CB2A9/0?term=2";
	String emojiList = "☘⭐✨☄☀⛅☁⛈⚡❄☃⛄☂☔ ";
	String DefXmlCard = "{\"app\":\"com.tencent.miniapp\",\"desc\":\"\",\"view\":\"all\",\"ver\":\"1.0.0.89\",\"prompt\":\"绿逗\",\"appID\":\"\",\"sourceName\":\"\",\"actionData\":\"\",\"actionData_A\":\"\",\"sourceUrl\":\"\",\"meta\":{\"all\":{\"buttons\":[{\"action\":\"http://www.qq.com\",\"name\":\"MessageTitle\"}],\"jumpUrl\":\"\",\"preview\":\"MessagePic\",\"summary\":\"MessageData\",\"title\":\"HELLO\"}},\"config\":{\"forward\":true},\"text\":\"\",\"extraApps\":[],\"sourceAd\":\"\",\"extra\":\"\"}";
}
new File(RootPath+"data/cache/").mkdirs();
GameStatusClass DefInfo = new GameStatusClass();
public class MessageApi
{
	public void FixAndSendMsg(String GroupUin,String text,String imagePath,boolean MustImage)
	{
		if(item.GetItemDataInt(GroupUin,"GameDic","配置","消息模式")==1)
		{
			if(!item.GetItemData(GroupUin,"GameDic","配置","图片").isEmpty())
			{
				if(imagePath.equals(DefInfo.CardDefImages))
				{
					imagePath=item.GetItemData(GroupUin,"GameDic","配置","图片");
				}
			}
			MyMsgApi.Message_Send_Group_Card(GroupUin,FixMsgCard(text,imagePath));
		}
		else if(item.GetItemDataInt(GroupUin,"GameDic","配置","消息模式")==2)
		{
			if(!item.GetItemData(GroupUin,"GameDic","配置","图片").isEmpty())
			{
				if(imagePath.equals(DefInfo.CardDefImages))
				{
					imagePath=item.GetItemData(GroupUin,"GameDic","配置","图片");
				}
			}
			MyMsgApi.Group_Send_Mix_P_Text(GroupUin,DefInfo.GameTheName,imagePath,FixMsg2(text.replace("\n\n\n","")));
		}
		else
		{
			if(MustImage)
			{
				MyMsgApi.Message_Send_Group_image(GroupUin,imagePath);
			}
			MyMsgApi.Message_Send_Group(GroupUin,FixMsg(text).replace("\n\n\n",""));
		}
	}
	public String FixMsg(String text)
	{
		String Mtt = DefInfo.GameTheName+"\n"+text;
		Mtt = Mtt.replace("[e]",GetRamdomTextChar(DefInfo.emojiList));
		Mtt = Mtt.replace("[time]",GetNowTime());
		return Mtt;
	}
	public String FixMsg2(String text)
	{
		String Mtt = text;
		Mtt = Mtt.replace("[e]",GetRamdomTextChar(DefInfo.emojiList));
		Mtt = Mtt.replace("[time]",GetNowTime());
		return Mtt;
	}
	public String FixMsgCard(String text,image)
	{
		String Mtt = DefInfo.DefXmlCard;
		text = text.replace("[e]",GetRamdomTextChar(DefInfo.emojiList));
		text = text.replace("[time]",GetNowTime());
		Mtt = Mtt.replace("MessageData",text);
		Mtt = Mtt.replace("MessagePic",image);
		Mtt = Mtt.replace("MessageTitle",DefInfo.GameTheName);
		return Mtt;
	}
	public String GetRamdomTextChar(String text)
	{
		String mytext = text;
		ArrayList list = new ArrayList();
		int index = 0;
		while(index < mytext.length())
		{
			int offset = mytext.offsetByCodePoints(index,1);
			list.add(index);
			index = offset;
		}
		int rnd = (int) (Math.random()*(list.size()-1));
		return mytext.substring((int)list.get(rnd),(int)list.get(rnd+1));
	}
}
MessageApi MyMsg = new MessageApi();