int NowSaveDialog = item.GetItemDataInt("AllFlags","notice","version","showVersion");
try{
	int NewNoticeVersion = Integer.parseInt(http.get("https://xss1566-1251707849.cos.ap-chengdu.myqcloud.com/MyJava/noticeTip.txt"));
	if(NewNoticeVersion>NowSaveDialog)
	{
		String NoticeText = http.get("https://xss1566-1251707849.cos.ap-chengdu.myqcloud.com/MyJava/noticeText.txt");
		item.SetItemData("AllFlags","notice","version","showVersion",NewNoticeVersion);
		Toast("绿逗公告\n"+NoticeText);
		MakeNoticeDialog(NoticeText);
	}
}
catch(e)
{}