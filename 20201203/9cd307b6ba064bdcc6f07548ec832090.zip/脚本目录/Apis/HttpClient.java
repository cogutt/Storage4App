BugHttpClient httpClient = new BugHttpClient();
httpClient.setAutoUnicodeToString(true);
httpClient.setTimeout(10000);
public class HttpApi
{
	public String get(String url)
	{
		String str = "";
		for(int i = 0; i < 5; i++)
		{
			BugHttpClient.Data map = new BugHttpClient.Data();
			Result result = httpClient.get(map, url, "");
			str = result.getResult();
			if(str.contains("java.net") && str.contains("Exception")) continue;
			if(str.contains("com.bug.http")) continue;
			return str;
		}
		return "调用失败";
	}
	public String get2(String url, int timeOut)
	{
		BugHttpClient.Data aadta = new BugHttpClient.Data();
		BugHttpClient httpcli = new BugHttpClient();
		httpcli.setTimeout(timeOut);
		Result result = httpcli.get(aadta, url, "");
		String str = result.getResult();
		if(str.contains("java.net"))
		{
			return "";
		}
		if(str.contains("com.bug.http"))
		{
			return "";
		}
		return str;
	}
	public DownloadToFile(String url, filepath) throws Exception
	{
		BugHttpClient.Data adata = new BugHttpClient.Data();
		Result result = httpClient.get(adata, url, "");
		InputStream is = result.getInputStream();
		byte[] bs = new byte[1024];
		int len;
		FileOutputStream out = new FileOutputStream(filepath, false);
		while((len = is.read(bs)) != -1)
		{
			out.write(bs, 0, len);
		}
		out.close();
		is.close();
	}
}
HttpApi http = new HttpApi();