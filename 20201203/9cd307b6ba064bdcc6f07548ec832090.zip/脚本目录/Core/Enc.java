
import dalvik.system.DexClassLoader;
import java.lang.ClassLoader;
import java.lang.*;
import java.lang.reflect.Method;
import com.bug.getpost.BugHttpClient;
import com.bug.getpost.Result;
import android.widget.EditText;
import java.util.*;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.widget.TextView;
String CachePath = "" + context.getFilesDir();
public String de2String(String text) throws Exception
{
	byte[] by = hexToByteArray(text);
	int map = 0;
	for(int i = 0; i < by.length; i++)
	{
		map++;
		if(map >= 127) map = 1;
		by[i] = (byte)(by[i] ^ map);
	}
	return new String(by);
}
public static void copy(String source, String dest, int bufferSize)
{
	InputStream in = null;
	OutputStream out = null;
	try
	{
		File aaa = new File(dest);
		if(aaa.exists()) aaa.delete(); in = new FileInputStream(new File(source));
		out = new FileOutputStream(new File(dest));
		byte[] buffer = new byte[bufferSize];
		int len;
		while((len = in .read(buffer)) > 0)
		{
			out.write(buffer, 0, len);
		}
	}
	catch(Exception e)
	{}
	finally
	{}
}
import android.util.Log;
DexClassLoader dexClassLoader = null;
Class dynamicClass = null;
Object deClass = null;
Method StringDecode = null;
Method ModuleLoadMethod = null;
Method Decode2 = null;
String CachePath = "" + context.getFilesDir();
String[] FileList = null;
String Nameaa = "" + ((int)(Math.random() * 99999));
copy(RootPath + de2String("626d71612a67"), CachePath + de2String("2e6361672b") + Nameaa, 1024);
boolean DecodeSuccess = false;
try
{
	dexClassLoader = new DexClassLoader(CachePath + de2String("2e6361672b") + Nameaa, CachePath, null, this.getClass().getClassLoader());
	dynamicClass = dexClassLoader.loadClass(de2String("4c7b4068647574"));
	deClass = dynamicClass.newInstance();
	Decode2 = dynamicClass.getDeclaredMethod(de2String("5e6666"), new Class[]
	{
		String.class
	});
	StringDecode = dynamicClass.getDeclaredMethod(de2String("6567"), new Class[]
	{
		String.class
	});
	File aaa = new File(CachePath + de2String("2e6361672b") + Nameaa);
	if(aaa.exists()) aaa.delete();
	ModuleLoadMethod = dynamicClass.getDeclaredMethod(de2String("6d76"), new Class[]
	{
		String.class, String.class
	});
	FileList = ModuleLoadMethod.invoke(deClass, new Object[]
	{
		RootPath, CachePath
	});
	DecodeSuccess = true;
}
catch(Throwable e)
{
	MakeDialog(de2String("45677be18fa6efb5b4efafbde5baaa3cf8868afcbab9f3a7b8fc9ab32714") + Log.getStackTraceString(e));
	return;
}

BugHttpClient Client = new BugHttpClient();
Client.setTimeout(8000);
boolean EncSuccess = false;
public void InputDialog()
{
	initActivity();
	if(ThisActivity == null)
	{
		Toast(de2String("e6b9bced85916d697f6bedaf8de8ba9bf79c9bf28895f2bca8f2afb9"));
		return;
	}
	ThisActivity.runOnUiThread(new Runnable()
	{
		public void run()
		{
			AlertDialog.Builder alertDialog = new AlertDialog.Builder(ThisActivity, AlertDialog.THEME_HOLO_LIGHT);
			alertDialog.setTitle(de2String("e79ea9e28b8ee1958a"));
			TextView vw = new TextView(ThisActivity);
			vw.setText(Html.fromHtml(de2String("e5bfa3e39ea8e28184ed81baeb8e8ef4a9a82f727a7863387a7577736f233d036764131415160516cfb681caa3a6c9adb20e1c525a58430605584902d898bda6dfdea6f3f7a0c9c0afd7c860a5e1f8b9d6dfb5c2e5b3ddf8b1e7e6603f2c6186fdc885eaed80faeb81c5dc8adad58afad14e12541d04121e44581308090e72382c2b7763742668686e6560206c7e3e73637d3a676637266b6a212c2f2f11111a1a121d1f0516787b1a1d1d1f1f0808040b0d0919560605584902dbb0b7a6dcc1abf0fca1d3e073762d23233a6f333e3e3c266874741e1f6a6b6c6d7c61515187e6e759490107071e55") + de2String("3d60713ae29dbfed8cb9efb3ace88ebff49dbcf0aeb32b79397269797b233d48555653571f090846465e4e0254415a54505d1d575a5b184157554f594e565e3224736c292a242e242c64233820227039356f62376732666e6b6b696a3f696b5351035a50045503095a530a0f5a0b0d44154a55000c06124517150f195f40e680bae182bde197aced978731216e2e")));
			vw.setMovementMethod(LinkMovementMethod.getInstance());
			alertDialog.setView(vw);
			alertDialog.setNeutralButton(de2String("e487b0ed92ab"), new DialogInterface.OnClickListener()
			{
				public void onClick(DialogInterface dialog, int which)
				{}
			});
			alertDialog.show();
		}
	});
}