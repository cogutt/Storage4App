public void MakeDialog(Object text)
{
	initActivity();
	ThisActivity.runOnUiThread(new Runnable()
	{
		public void run()
		{
			AlertDialog alertDialog = new AlertDialog.Builder(ThisActivity,AlertDialog.THEME_HOLO_LIGHT).create();
			alertDialog.setTitle("提示");
			alertDialog.setMessage(text);
			alertDialog.setButton(DialogInterface.BUTTON_NEGATIVE, "确定", new DialogInterface.OnClickListener()
			{
				public void onClick(DialogInterface dialog, int which)
				{}
			});
			alertDialog.show();
		}
	});
}
public void MakeNoticeDialog(Object text)
{
	initActivity();
	ThisActivity.runOnUiThread(new Runnable()
	{
		public void run()
		{
			AlertDialog alertDialog = new AlertDialog.Builder(ThisActivity,AlertDialog.THEME_HOLO_LIGHT).create();
			alertDialog.setTitle("公告");
			alertDialog.setMessage(text);
			alertDialog.setButton(DialogInterface.BUTTON_NEGATIVE, "确定", new DialogInterface.OnClickListener()
			{
				public void onClick(DialogInterface dialog, int which)
				{}
			});
			alertDialog.show();
		}
	});
}