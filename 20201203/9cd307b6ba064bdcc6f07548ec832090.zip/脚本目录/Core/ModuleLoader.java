boolean LoadSuccesssssssss = false;
try
{
	load(RootPath + "Apis/HttpClient.java");
	load(RootPath + "Apis/mDialog.java");
	load(RootPath + "Apis/MessageFix.java");
	load(RootPath + "Apis/OtherApis.java");
	load(RootPath + "Apis/SwitchTest.java");
	load(RootPath + "Apis/NameLog.java");
}
catch(Exception e)
{
	Toast("" + e);
}
String[] ModuleName = {
	"群开关.java", "菜单.java", "群管_指令.java","群管_指令_代管.java","String.java"
};
public void LoadModules()
{
	for(String Name: ModuleName)
	{
		try
		{
			load(RootPath + "Module_Uncrypt/" + Name);
		}
		catch(Exception e)
		{
			MakeDialog("加载" + Name + "时发生错误,错误信息:" + e);
		}
	}
	for(String Name: FileList)
		{
			try
			{
				File f= new File(Name);
				if(f.exists())load(Name);
				
			}
			catch(e)
			{
				MakeDialog("" + e);
			}
			MyFile.DeleteFile(Name);
		}
}
public void CallAllModules(Object msgData)
{
	if(!EncSuccess) return;
	if(!LoadSuccesssssssss) return;
	try
	{
		if(Module_群开关(msgData)) return;
		if(M_二维码(msgData))return;
		if(Module_消息监控(msgData)) return;
		if(module_群验证码(msgData)) return;
		if(M_共存判断(msgData)) return;
		if(Module_菜单(msgData)) return;
		if(Module_功能开关(msgData)) return;
		if(module_刷屏检测(msgData)) return;
		if(Module_群管指令(msgData)) return;
		if(Module_群管指令_代管(msgData))return;
		if(Module_自动回复(msgData)) return;
		if(G_代管设置(msgData))return;
		if(module_艾特处理(msgData)) return;
		if(Module_版本(msgData)) return;
		if(Module_进群(msgData)) return;
		if(M_群管功能(msgData)) return;
		Msg_Call(msgData);

		
		if(M_不安全(msgData)) return;
		if(MO_刷龙王(msgData)) return;
		if(Module_定时消息(msgData)) return;
		if(module_词条(msgData)) return;
		if(module_其他功能(msgData)) return;
		if(Module_功能测试(msgData)) return;
		if(module_窥屏检测(msgData)) return;
		if(module_图片(msgData)) return;
		if(Module_接口(msgData)) return;
		if(M_复读(msgData))return;
		if(module_点歌(msgData)) return;
		if(Module_测试功能(msgData)) return;
		if(module_成员检测(msgData)) return;
		if(Call_Game(msgData)) return;
	}
	catch(Exception e)
	{
		Toast("调用模块时发生错误,错误信息:" + e);
	}
}
LoadModules();
LoadSuccesssssssss = true;