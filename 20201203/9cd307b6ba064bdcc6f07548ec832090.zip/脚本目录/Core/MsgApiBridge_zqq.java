MyUin = mQQ;
MyName = mName;
public class MessageObject
{
	String Message_Content;
	int Message_Type;
	long Message_Time;
	String Message_UserUin;
	String Message_GroupUin;
	boolean isGroup;
	String[] atList;
	String nickName;
	Object msg;
	boolean atMe;
	String[] PicList;
	String QRResult;
}
public class Zqq_MsgApi
{
	public void OnMsgMessage(MessageObject msg)
	{
		CallAllModules(msg);
	}
	public void Message_Send_Group(String GroupUin, String Message)
	{
		send(createData(true,GroupUin),Message);
	}
	public void Message_Send_Group(String GroupUin, String Message,String[] AtList)
	{
		send(createData(true,GroupUin),Message,AtList);
	}
	public void Message_Send_Friend(String FriendUin, String Message)
	{
		send(createData(false,FriendUin),Message);
	}
	public void Message_Send_Private(String GroupUin, String QQUin, String Message)
	{
		send(createPrivateChatData(GroupUin,QQUin),Message);
	}
	public void Message_Send_Group_image(String GroupUin, String Message)
	{
		sendPhoto(createData(true,GroupUin),Message);
	}
	public void Message_Send_Friend_image(String GroupUin, String Message)
	{
		sendPhoto(createData(false,GroupUin),Message);
	}
	public void Message_Send_Private_image(String GroupUin, String QQUin, String Message)
	{
		sendPhoto(createPrivateChatData(GroupUin,QQUin),Message);
	}
	public void Message_Send_Group_voice(String GroupUin, String Message)
	{
		sendPtt(createData(true,GroupUin),Message);
	}
	public void Message_Send_Friend_voice(String GroupUin, String Message)
	{
		sendPtt(createData(false,GroupUin),Message);
	}
	public void Message_Send_Private_voice(String GroupUin, String QQUin, String Message)
	{
		sendPtt(createPrivateChatData(GroupUin,QQUin),Message);
	}
	public void Message_Send_Group_Card(String GroupUin, String Message)
	{
		sendCard(createData(true,GroupUin),Message);
	}
	public void Message_Send_Friend_Card(String GroupUin, String Message)
	{
		sendCard(createData(false,GroupUin),Message);
	}
	public void Message_Send_Private_Card(String GroupUin, String QQUin, String Message)
	{
		sendCard(createPrivateChatData(GroupUin,QQUin),Message);
	}
	public void Group_Forbidden(String GroupUin, String QQUin, long time)
	{
		try{
			shutUp(GroupUin, QQUin, time);
		}
		catch(Throwable th)
		{
			Toast("调用到复读机接口时出现问题,可能是复读机提供的接口未适配QQ:"+th);
		}
		
	}
	public void Group_Forbidden_All(String GroupUin,boolean flag)
	{
		try{
		    shutUp(GroupUin,flag);
		}
		catch(Throwable th)
		{
			Toast("调用到复读机接口时出现问题,可能是复读机提供的接口未适配QQ:"+th);
		}
	}
	public void Group_Kick(String GroupUin, String QQUin, boolean black)
	{
		removeTroop(GroupUin,QQUin,black);
	}
	public void Group_ChangeName(String GroupUin, String QQUin, String Name)
	{
		alterNickName(GroupUin,QQUin,Name);
	}
	public void Group_SetTitle(String GroupUin, String QQUin, String Title)
	{
		setTitle(GroupUin,QQUin,Title);
	}
	public void Group_Send_Mix_P_Text(String GroupUin,String Title,String PicLink,String Text)
	{
		String PICUUID = GetUUIDByLink(PicLink);
		if(PICUUID.isEmpty())
		{
			PICUUID = PicLink;
			String[][] mMsg= new String[][]{{"1",Title},{"2",PicLink},{"1",Text}};
		    sendMixed(createData(true,GroupUin),mMsg);
			return;
		}
		File f = new File(RootPath + "data/cache/"+PICUUID);
		if(!f.exists())
		{
			http.DownloadToFile(PicLink,RootPath + "data/cache/"+PICUUID);
		}
		String[][] mMsg= new String[][]{{"1",Title},{"2",RootPath + "data/cache/"+PICUUID},{"1",Text}};
		sendMixed(createData(true,GroupUin),mMsg);
	}
}
Zqq_MsgApi MyMsgApi = new Zqq_MsgApi();
public void onMsg(Object data)
{
	MessageObject obj = new MessageObject();
	obj.atMe = data.atMe;
	if(data.isGroup)
	{
		obj.Message_Content = data.content;
		obj.Message_Type = 0;
		obj.Message_Time = data.time;
		obj.Message_UserUin = data.sendUin;
		obj.Message_GroupUin = data.friendUin;
		obj.isGroup = true;
		obj.atList = data.atList;
		obj.nickName = data.nickName;
		obj.msg = data;
	}
	else
	{
		obj.Message_Content = data.content;
		obj.Message_Type = 0;
		obj.Message_Time = data.time;
		obj.Message_UserUin = data.friendUin;
		obj.Message_GroupUin = data.sendUin;
		obj.isGroup = false;
		obj.atList = data.atList;
		obj.nickName = data.nickName;
		obj.msg = data;
	}
	MyMsgApi.OnMsgMessage(obj);
}
public void onMixedMsg(Object data)
{
	
	MessageObject obj = new MessageObject();
	obj.atMe = data.atMe;
	if(data.isGroup)
	{
		
		obj.Message_Type = 4;
		String msgMix = "";
		List mList = new ArrayList();
		
		for(Object sobj : data.content)
		{
			if(sobj.type==1)
			{
				msgMix = msgMix + sobj.content;
			}
			if(sobj.type==2)
			{
				msgMix = msgMix + "[图片]";
				mList.add(sobj.content);
			}
		}
		obj.Message_Content = msgMix;
		obj.PicList = mList.toArray(new String[0]);
		obj.Message_Time = data.time;
		obj.Message_UserUin = data.sendUin;
		obj.Message_GroupUin = data.friendUin;
		obj.isGroup = true;
		obj.nickName = data.nickName;
		obj.msg = data;
		
		MyMsgApi.OnMsgMessage(obj);
		
	}
}
public void onPicMsg(Object data)
{
		MessageObject obj = new MessageObject();
	if(data.isGroup)
	{
		obj.Message_Content = data.content;
		obj.Message_Type = 1;
		obj.Message_Time = data.time;
		obj.Message_UserUin = data.sendUin;
		obj.Message_GroupUin = data.friendUin;
		obj.isGroup = true;
		obj.nickName = data.nickName;
		obj.msg = data;
	}
	else
	{
		obj.Message_Content = data.content;
		obj.Message_Type = 1;
		obj.Message_Time = data.time;
		obj.Message_UserUin = data.friendUin;
		obj.Message_GroupUin = data.sendUin;
		obj.isGroup = false;
		obj.nickName = data.nickName;
		obj.msg = data;
	}
	MyMsgApi.OnMsgMessage(obj);
}
public void onCardMsg(Object data)
{
	MessageObject obj = new MessageObject();
	if(data.isGroup)
	{
		obj.Message_Content = data.content;
		obj.Message_Type = 2;
		obj.Message_Time = data.time;
		obj.Message_UserUin = data.sendUin;
		obj.Message_GroupUin = data.friendUin;
		obj.isGroup = true;
		obj.nickName = data.nickName;
		obj.msg = data;
	}
	else
	{
		obj.Message_Content = data.content;
		obj.Message_Type = 2;
		obj.Message_Time = data.time;
		obj.Message_UserUin = data.friendUin;
		obj.Message_GroupUin = data.sendUin;
		obj.isGroup = false;
		obj.nickName = data.nickName;
		obj.msg = data;
	}
	MyMsgApi.OnMsgMessage(obj);
}
public void onJoin(String GroupUin,String QQUin)
{
	MessageObject obj = new MessageObject();
	obj.Message_Content = "";
	obj.Message_Type = 3;
	obj.Message_Time = System.currentTimeMillis()/1000;
	obj.Message_UserUin = QQUin;
	obj.Message_GroupUin = GroupUin;
	obj.isGroup = true;
	obj.nickName = "";
	MyMsgApi.OnMsgMessage(obj);
}

