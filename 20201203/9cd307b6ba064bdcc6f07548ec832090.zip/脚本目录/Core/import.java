import com.bug.getpost.BugHttpClient;
import com.bug.getpost.Result;
import com.bug.utils.FieldUtils;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Environment;

import android.app.Application;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ActivityManager;

import android.widget.Toast;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.DatePicker;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TimePicker;
import android.widget.VideoView;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.Context;
import android.content.DialogInterface.OnMultiChoiceClickListener;

import android.util.Log;

import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;

import android.view.View;
import android.view.ViewGroup;
import android.view.Gravity;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;

import org.json.JSONArray;
import org.json.JSONObject;

import java.lang.ClassLoader;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.CharSequence;

import java.text.SimpleDateFormat;
import java.text.DateFormat;
import java.text.ParseException;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

import java.io.*;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import java.net.Socket;
import android.net.ConnectivityManager;

import dalvik.system.DexClassLoader;

import com.tencent.mobileqq.imcore.IMCore;

import java.io.InputStream; 
import java.io.OutputStream;
import java.net.Socket;