public boolean Module_菜单(Object msgData)
{
	if(!MySwitch.CheckSwitch(msgData.Message_GroupUin,"菜单")) return false;
	if(MySwitch.CheckSwitch(msgData.Message_GroupUin,"菜单限制") && !IsGroupAdmin(msgData.Message_GroupUin,msgData.Message_UserUin)) return false;
	//一级菜单
	if(msgData.Message_Content.equals("菜单"))
	{
		String retText = "图片系统☀音乐系统☀词条系统\n接口系统☀群管系统☀娱乐系统\n定时系统☀开关系统☀配置设置\n艾特处理☀其他功能☀附加功能\n自动回复☀试验功能☀版本信息";
		MyMsg.FixAndSendMsg(msgData.Message_GroupUin,retText,DefInfo.CardDefImages,false);
	}
	if(msgData.Message_Content.equals("图片系统"))
	{
		String retText = "☀看风景☀看壁纸☀看动漫\n☀看美女☀看汽车☀看动物\n☀看剧照☀看美腿\n☀制作二维码+内容";
		MyMsg.FixAndSendMsg(msgData.Message_GroupUin,retText,DefInfo.CardDefImages,false);
	}
	if(msgData.Message_Content.equals("音乐系统"))
	{
		String retText = "☀点歌+歌名\n☀QQ(网易云)点歌+歌名";
		MyMsg.FixAndSendMsg(msgData.Message_GroupUin,retText,DefInfo.CardDefImages,false);
	}
	if(msgData.Message_Content.equals("词条系统"))
	{
		String retText = "☀彩虹屁☀毒鸡汤☀荤段子\n☀微博热搜☀歇后语☀随机诗句\n☀舔狗日记☀精神小伙☀土味情话\n☀来句骚话☀来个笑话☀网易乐评\n藏头诗 群主吊毛☀历史上的今天";
		MyMsg.FixAndSendMsg(msgData.Message_GroupUin,retText,DefInfo.CardDefImages,false);
	}
	if(msgData.Message_Content.equals("接口系统"))
	{
		String retText = "☀垃圾分类+物品☀代挂查询+Q号\n☀加群链接+群号☀加好友链接+Q号\n☀域名查询+域名☀菜谱+食材\n☀谁在窥屏☀谁在窥屏2☀xx天气\n☀解析视频+视频链接(B站,微视,抖音,皮皮虾)(不要包含中文)\n\n\n";
		MyMsg.FixAndSendMsg(msgData.Message_GroupUin,retText,DefInfo.CardDefImages,false);
	}
	if(msgData.Message_Content.equals("群管系统"))
	{
		String retText = "基础功能|黑白名单|名片监测\n发言检测|进群验证|进群欢迎\n代码处理|刷屏检测|成员检测\n其他群管功能|本群群管状态\n设置代管权限\n\n\n\n";
		MyMsg.FixAndSendMsg(msgData.Message_GroupUin,retText,DefInfo.CardDefImages,false);
	}
	if(msgData.Message_Content.equals("成员检测"))
	{
		String retText = "检测不发言大于+时间\n检测加群晚于+时间\n扫描本群名片\n(检测的时候请先点进群列表刷新一次)";
		MyMsg.FixAndSendMsg(msgData.Message_GroupUin,retText,DefInfo.CardDefImages,false);
	}
	if(msgData.Message_Content.equals("其他群管功能"))
	{
		String retText = "投票禁言@xx 时间|票数\n投票踢出@xx 票数\n开启/关闭自助头衔\n无视@xx 解除无视@xx";
		MyMsg.FixAndSendMsg(msgData.Message_GroupUin,retText,DefInfo.CardDefImages,false);
	}
	if(msgData.Message_Content.equals("定时系统"))
	{
		String retText = "定时消息\n整点报时";
		MyMsg.FixAndSendMsg(msgData.Message_GroupUin,retText,DefInfo.CardDefImages,false);
	}
	if(msgData.Message_Content.equals("配置设置"))
	{
		String retText = "切换文字模式\n切换图文模式\n切换卡片模式\n设置卡片图片\n启动功能\n关闭功能\n所有群设置";
		MyMsg.FixAndSendMsg(msgData.Message_GroupUin,retText,DefInfo.CardDefImages,false);
	}
	if(msgData.Message_Content.equals("自动回复"))
	{
		String retText = "添加精确回复 触发语|回复语";
		retText = retText + "\n添加模糊回复 触发语|回复语";
		retText = retText + "\n查看精确/模糊回复列表";
		MyMsg.FixAndSendMsg(msgData.Message_GroupUin,retText,DefInfo.CardDefImages,false);
	}
	//二级菜单_定时系统
	if(msgData.Message_Content.equals("定时消息"))
	{
		String text = "设置定时消息+格式参数";
		text = text + "\n添加(循环|每日)(文字|图片|卡片|语音)消息+时间|内容";
		text = text + "\n删除任务+任务序号";
		text = text + "\n查看所有定时任务";
		text = text + "\n清空所有任务";
		text = text + "\n(文字消息后加$ds可以只触发指令不发出消息)\n\n\n\n";
		MyMsg.FixAndSendMsg(msgData.Message_GroupUin,text,DefInfo.CardDefImages,false);
	}
	if(msgData.Message_Content.equals("查看消息设置说明"))
	{
		String text = "---消息格式---";
		text = text + "\n任务序号|任务类型|消息类型|时间|任务内容";
		text = text + "\n消息类型:1.文字 2.卡片 3.图片 4.语音";
		text = text + "\n(文字,卡片中不能包含|符号,图片写网址,语音写文件名,文件放在PTT目录中)";
		text = text + "\n任务类型:1.循环消息 2.每日消息 3.定时消息";
		text = text + "\n时间格式:1.延时(单位分钟,不能少于10秒) 2. 23:59  3.2020/1/1 23:59\n\n\n";
		MyMsg.FixAndSendMsg(msgData.Message_GroupUin,text,DefInfo.CardDefImages,false);
	}
	if(msgData.Message_Content.equals("整点报时"))
	{
		String text = "---整点报时---";
		text = text+ "\n开启/关闭整点报时";
		text = text +"\n设置报时文本+文本";
		text = text +"\n设置报时卡片";
		text = text +"\n查看报时卡片/文本";
		text = text +"\n(支持变量[Y][M][D][h][m][s][wd][yy][nl])";
		text = text +"\n(年/月/日/小时/分钟/秒/星期几/一言/农历)\n\n\n\n\n\n\n";
		MyMsg.FixAndSendMsg(msgData.Message_GroupUin,text,DefInfo.CardDefImages,false);
	}
	//二级菜单_	群管系统
	if(msgData.Message_Content.equals("基础功能"))
	{
		String text = "踢出@xx  警告@xx";
		text = text+ "\n解禁@xx  禁言@xx+时间";
		text = text+ "\n全员禁言  全员解禁";
		text = text+ "\n添加代管@xx  删除代管@xx";
		text = text+ "\n查看代管列表";
		MyMsg.FixAndSendMsg(msgData.Message_GroupUin,text,DefInfo.CardDefImages,false);
	}
	if(msgData.Message_Content.equals("黑白名单"))
	{
		String text = "拉黑@xx";
		text = text + "\n删除黑名 QQ号";
		text = text + "\n添加白名单@xx";
		text = text + "\n删除白名单@xx";
		text = text + "\n查询黑/白名单";
		text = text + "\n清空黑/白名单";
		text = text + "\n全局拉黑@xx";
		text = text + "\n删除全局黑名 QQ";
		text = text + "\n查看全局黑名单\n\n\n\n\n\n\n\n\n";
		MyMsg.FixAndSendMsg(msgData.Message_GroupUin,text,DefInfo.CardDefImages,false);
	}
	if(msgData.Message_Content.equals("发言检测"))
	{
		String text = "添加/删除违禁词 违禁词";
		text = text + "\n违禁词列表";
		text = text + "\n开启/关闭违禁词(撤回|禁言|踢出)";
		text = text + "\n设置禁言时间 时间(秒)";
		text = text + "\n设置警告踢出次数 次数";
		text = text + "\n清空警告次数 QQ号";
		text = text + "\n开启/关闭二维码检测";
		text = text + "\n开启/关闭二维码违禁\n\n\n";
		MyMsg.FixAndSendMsg(msgData.Message_GroupUin,text,DefInfo.CardDefImages,false);
	}
	if(msgData.Message_Content.equals("名片监测"))
	{
		String text = "开启/关闭自动更改名片";
		text = text + "\n设置名片前缀 前缀";
		text = text + "\n设置名片后缀 后缀";
		text = text + "\n添加/删除违禁名片词+内容(默认使用正则匹配)";
		text = text + "\n设置/关闭违禁名片处理+(随机修改|群内提醒)";
		text = text + "\n改名@xx 新名片\n\n\n\n\n\n\n\n";
		MyMsg.FixAndSendMsg(msgData.Message_GroupUin,text,DefInfo.CardDefImages,false);
	}
	if(msgData.Message_Content.equals("代码处理"))
	{
		String text = "开启/关闭回执作业(撤回/踢出/全禁/拉黑)";
		text = text + "\n开启/关闭所有卡片(撤回/踢出/禁言)";
		text = text + "\n设置所有卡片禁言时间+时间(秒)";
		MyMsg.FixAndSendMsg(msgData.Message_GroupUin,text,DefInfo.CardDefImages,false);
	}
	if(msgData.Message_Content.equals("进群验证"))
	{
		String text = "开启/关闭进群验证";
		text = text + "\n设置进群验证时间+时间(秒)";
		text = text + "\n切换验证方式";
		MyMsg.FixAndSendMsg(msgData.Message_GroupUin,text,DefInfo.CardDefImages,false);
	}
	if(msgData.Message_Content.equals("进群欢迎"))
	{
		String text = "清除/设置(进群|私聊)欢迎文字+内容";
		text = text + "\n设置/清除进群欢迎(卡片|图片)";
		text = text + "\n设置进群禁言时间+时间";
		text = text + "\n开启/关闭(进群|私聊)欢迎";
		text = text + "\n开启/关闭进群语音欢迎";
		text = text + "\n开启/关闭入群禁言";
		text = text + "\n查看本群(进群|私聊)欢迎词";
		text = text + "\n查看支持变量\n\n\n\n\n\n\n\n";
		MyMsg.FixAndSendMsg(msgData.Message_GroupUin,text,DefInfo.CardDefImages,false);
	}
	if(msgData.Message_Content.equals("刷屏检测"))
	{
		String text = "开启/关闭刷屏检测";
		text = text + "\n设置个人检测频率+频率(每2秒条数)";
		text = text + "\n设置刷屏禁言时间+秒数";
		text = text + "\n开启/关闭全群复读检测";
		text = text + "\n设置全群复读检测数+数量";
		text = text + "\n设置全群复读禁言时间+时间\n\n\n";
		MyMsg.FixAndSendMsg(msgData.Message_GroupUin,text,DefInfo.CardDefImages,false);
	}
	if(msgData.Message_Content.equals("试验功能"))
	{
		String text = "开启/关闭撤回@xx";
		text = text + "\n进群测试+QQ号";
		text = text + "\n报时测试";
		text = text + "\n自动复读@xx 概率";
		text = text + "\n关闭自动复读@xx ";
		text = text + "\n不安全功能";
		text = text + "\n刷龙王助手";
		text = text + "\n(注意,试验功能请自己研究,不提供帮助)\n\n\n\n\n\n\n\n\n";
		MyMsg.FixAndSendMsg(msgData.Message_GroupUin,text,DefInfo.CardDefImages,false);
	}
	if(msgData.Message_Content.equals("刷龙王助手"))
	{
		String text = "我要龙王+等级(0:1秒一次,1:3秒一次,2:1分钟10次,3:1分钟5次)";
        text = text + "\n停止刷龙王";
		MyMsg.FixAndSendMsg(msgData.Message_GroupUin,text,DefInfo.CardDefImages,false);
	}
	
	if(msgData.Message_Content.equals("不安全功能"))
	{
		if(!DontSafe) 
		{
			MyMsg.FixAndSendMsg(msgData.Message_GroupUin,"当前该功能不可用\n发送 开启不安全功能  来开启该功能",DefInfo.CardDefImages,false);
			return false;
		}
		String text = "搜影视+内容";
		text = text + "\n百度搜图+名字";
		MyMsg.FixAndSendMsg(msgData.Message_GroupUin,text,DefInfo.CardDefImages,false);
		
	}
	if(msgData.Message_Content.equals("其他功能"))
	{
		String text = "看卡片";
		text = text + "\n看图片";
		text = text + "\n图转卡";
		text = text + "\n转(秀图|幻影|抖动|生日|爱你|征友)";
		MyMsg.FixAndSendMsg(msgData.Message_GroupUin,text,DefInfo.CardDefImages,false);
	}
	if(msgData.Message_Content.equals("查看支持变量"))
	{
		String text = "支持变量如下:";
		text = text + "\n[Time] 进群时间";
		text = text + "\n[Name] 名称";
		text = text + "\n[QQUin] QQ号";
		text = text + "\n[GroupUin] 群号";
		text = text + "\n[GroupName] 群名";
		MyMsg.FixAndSendMsg(msgData.Message_GroupUin,text,DefInfo.CardDefImages,false);
	}
	
	if(msgData.Message_Content.equals("艾特处理"))
	{
		String text = "艾特处理状态:"+(MySwitch.CheckSwitch(msgData.Message_GroupUin, "艾特处理") ? "开" : "关");
		text = text + "  艾特回复文字:"+(item.GetItemDataInt(msgData.Message_GroupUin, "Setting", "AtMeMessage", "Respone") == 1 ? "开" : "关");
		text = text + "\n艾特回复图片:"+(item.GetItemDataInt(msgData.Message_GroupUin, "Setting", "AtMeMessage", "ResponePic") == 1 ? "开" : "关");
		text = text + "  艾特回复语音:"+(item.GetItemDataInt(msgData.Message_GroupUin, "Setting", "AtMeMessage", "ResponeVoice") == 1 ? "开" : "关");
		text = text + "\n艾特禁言:"+(item.GetItemDataInt(msgData.Message_GroupUin, "Setting", "AtMeMessage", "Forbid") == 1 ? "开" : "关");
		text = text + "      艾特禁言时间:"+secondToTime(item.GetItemDataInt(msgData.Message_GroupUin, "Setting", "AtMeMessage", "ForbidTime"));
		text = text + "\n设置艾特回复语";
		text = text + "\n设置艾特禁言时间+时间";
		text = text + "\n设置艾特回复\n\n\n\n\n\n\n\n";
		MyMsg.FixAndSendMsg(msgData.Message_GroupUin,text,DefInfo.CardDefImages,false);
	}
	return false;
}