List OpenGroupList = new ArrayList(Arrays.asList(item.MakeListForItem("AllFlags", "Common", "OpenGroup")));
long LastRecvTime = 0;
boolean testMode = false;
public boolean Module_群开关(Object msgData)
{
	if(msgData.Message_UserUin.equals(mQQ))
	{
		if(msgData.Message_Content.equals("测试模式"))
		{
			testMode = true;
		}
	}
	if(testMode = false)
	{
		if(msgData.Message_Time < LastRecvTime - 20) return true;
		LastRecvTime = msgData.Message_Time;
	}
	if(msgData.Message_UserUin.equals(MyUin))
	{
		if(msgData.Message_Content.equals("启动功能"))
		{
			if(OpenGroupList.contains(msgData.Message_GroupUin))
			{
				Toast("该群已开启");
				return true;
			}
			item.SetItemData("AllFlags", "Common", "OpenGroup", msgData.Message_GroupUin, 1);
			OpenGroupList.add(msgData.Message_GroupUin);
			if(item.GetItemDataInt(msgData.Message_GroupUin, "GameDic", "配置", "消息模式") == 1)
			{
				String json = "{\"app\":\"com.tencent.miniapp\",\"desc\":\"\",\"view\":\"all\",\"ver\":\"1.0.0.89\",\"prompt\":\"绿逗\",\"appID\":\"\",\"sourceName\":\"\",\"actionData\":\"\",\"actionData_A\":\"\",\"sourceUrl\":\"\",\"meta\":{\"all\":{\"buttons\":[{\"action\":\"http://www.qq.com\",\"name\":\"启动成功\"}],\"jumpUrl\":\"\",\"preview\":\"imageurl\",\"summary\":\"\",\"title\":\"绿逗Java\"}},\"config\":{\"forward\":true},\"text\":\"\",\"extraApps\":[],\"sourceAd\":\"\",\"extra\":\"\"}";
				
				String imagePath = item.GetItemData(msgData.Message_GroupUin, "GameDic", "配置", "图片").isEmpty() ? DefInfo.CardDefImages : item.GetItemData(msgData.Message_GroupUin, "GameDic", "配置", "图片");
				json = json.replace("imageurl", imagePath);
				json = json.replace("yytext", http.get(ServiceRoot + "ct/yy"));
				MyMsgApi.Message_Send_Group_Card(msgData.Message_GroupUin, json);
			}
			else
			{
				MyMsgApi.Message_Send_Group(msgData.Message_GroupUin, "群聊" + getTroopName(msgData.Message_GroupUin) + "(" + msgData.Message_GroupUin + ")已开启");
			}
		}
		if(msgData.Message_Content.equals("关闭功能"))
		{
			if(!OpenGroupList.contains(msgData.Message_GroupUin))
			{
				Toast("该群未开启");
				return true;
			}
			item.DeleteItem("AllFlags", "Common", "OpenGroup", msgData.Message_GroupUin);
			OpenGroupList.remove(msgData.Message_GroupUin);
			if(item.GetItemDataInt(msgData.Message_GroupUin, "GameDic", "配置", "消息模式") == 1)
			{
				String json = "{\"app\":\"com.tencent.miniapp\",\"desc\":\"\",\"view\":\"all\",\"ver\":\"1.0.0.89\",\"prompt\":\"绿逗\",\"appID\":\"\",\"sourceName\":\"\",\"actionData\":\"\",\"actionData_A\":\"\",\"sourceUrl\":\"\",\"meta\":{\"all\":{\"buttons\":[{\"action\":\"http://www.qq.com\",\"name\":\"关闭成功\"}],\"jumpUrl\":\"\",\"preview\":\"imageurl\",\"summary\":\"\",\"title\":\"绿逗Java\"}},\"config\":{\"forward\":true},\"text\":\"\",\"extraApps\":[],\"sourceAd\":\"\",\"extra\":\"\"}";
				//String json = "{\"app\":\"com.tencent.qqpay.qqmp.groupmsg\",\"prompt\":\"绿逗Java\",\"ver\":\"1.0.0.7\",\"view\":\"groupPushView\",\"desc\":\"\",\"meta\":{\"groupPushData\":{\"time\":\"\",\"cancel_url\":\"http://www.baidu.com\",\"fromIcon\":\"\",\"report_url\":\"http://kf.qq.com/faq/180522RRRVvE180522NzuuYB.html\",\"bannerLink\":\"\",\"fromName\":\"name\",\"summaryTxt\":\"yytext\",\"bannerImg\":\"imageurl\",\"bannerTxt\":\"关闭成功\",\"item1Img\":\"\"}}}";
				String imagePath = item.GetItemData(msgData.Message_GroupUin, "GameDic", "配置", "图片").isEmpty() ? DefInfo.CardDefImages : item.GetItemData(msgData.Message_GroupUin, "GameDic", "配置", "图片");
				json = json.replace("imageurl", imagePath);
				json = json.replace("yytext", http.get(ServiceRoot + "ct/yy"));
				MyMsgApi.Message_Send_Group_Card(msgData.Message_GroupUin, json);
			}
			else
			{
				MyMsgApi.Message_Send_Group(msgData.Message_GroupUin, "群聊" + getTroopName(msgData.Message_GroupUin) + "(" + msgData.Message_GroupUin + ")已关闭");
			}
		}
		if(msgData.Message_Content.equals("所有群设置"))
		{
			initActivity();
			
			ViewAllGroup();
			record(msgData.msg);
		}
		if(msgData.Message_Content.equals("克隆该群数据"))
		{
			initActivity();
			SSSSGroup(msgData.Message_GroupUin);
		}
		if(msgData.Message_Content.startsWith("关闭群聊"))
		{
			String GroupUin = msgData.Message_Content.substring(4);
			item.DeleteItem("AllFlags", "Common", "OpenGroup", GroupUin);
			OpenGroupList.remove(GroupUin);
			MyMsgApi.Message_Send_Group(msgData.Message_GroupUin, "群聊" + GroupUin+"已关闭");
		}
		if(msgData.Message_Content.equals("刷新群状态"))
		{
			try{
				ArrayList TempOpenList = new ArrayList();
				Object[] troops = getGroups();
				int GroupNumber = troops.length;
				for(int i=0;i<GroupNumber;i++)
				{
					if(item.GetItemDataInt("AllFlags", "Common", "OpenGroup", troops[i].uin)==1)
					{
						TempOpenList.add(troops[i].uin);
					}
				}
				item.DeleteItemFile("AllFlags", "Common", "OpenGroup");
				OpenGroupList.clear();
				for(String OpenUin:TempOpenList)
				{
					item.SetItemData("AllFlags", "Common", "OpenGroup", OpenUin,1);
					OpenGroupList.add(OpenUin);
				}
				sendTip(msgData.msg,"刷新群状态完成,当前开启群数量为"+OpenGroupList.size());
			}
			catch(e)
			{
				Toast("刷新群状态失败,请确认你使用的是最新版的复读机"+e);
			}
		}
	}
	if(!msgData.isGroup)
	{
		UserCheck(msgData);
		Call_Game_Private(msgData);
		return true;
	}
	if(!OpenGroupList.contains(msgData.Message_GroupUin)) return true;
	return false;
}